package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hivep2q4 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

            Class.forName(driver);
            con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
            st=con.createStatement();

          //buckets by country and load data

            String sql1="CREATE TABLE olympicbuc(Athelete_Name string, age int,country string, year int, closing_date string, sport string,gold_medal int, "+ 
            "silver_medal int, bronze_medal int, total_medal int)clustered by(country) into 5 buckets row format delimited fields terminated by',' ";
            st.execute(sql1);
    
            String sql2="insert overwrite table olympicbuc select Athelete_Name,age, country, year, "
            		+ "closing_date, sport, gold_medal, silver_medal,bronze_medal, total_medal from olympic ";
            st.execute(sql2);

            System.out.println("bucket created and data loaded");
            con.close();
    }
    }


