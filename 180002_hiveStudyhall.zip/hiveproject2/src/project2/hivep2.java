package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hivep2 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

            Class.forName(driver);
            con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
            st=con.createStatement();

            //olympic table

            st.execute("CREATE TABLE IF NOT EXISTS " + "olympic(Athelete_Name string, age int, country string, year int, closing_date string, sport string, gold_medal int, silver_medal int,bronze_medal int, total_medal int) "
                    + "COMMENT 'EMP DETAILS' "
                    + "ROW FORMAT DELIMITED "
                    + "FIELDS TERMINATED BY ',' "
                    + "LINES TERMINATED BY '\n' "
                    + "STORED AS TEXTFILE");

            System.out.print("Table is created");
            con.close();}

}
