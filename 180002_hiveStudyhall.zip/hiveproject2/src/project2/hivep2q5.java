package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hivep2q5 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;
    private static ResultSet res=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

    	  Class.forName(driver);
          con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
          st=con.createStatement();

          //medal winning countries

          String sql1="select country, sum(total_medal)as total from olympic group by(country) ";
          res=st.executeQuery(sql1);
          while(res.next()){
                  System.out.println(res.getString("country")+"  "+res.getInt("total"));
    }
          con.close();
    }
    }


