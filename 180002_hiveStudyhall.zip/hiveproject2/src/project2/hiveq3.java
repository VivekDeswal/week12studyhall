package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hiveq3 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

            Class.forName(driver);
            con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
            st=con.createStatement();

            //partition by year and loading data

            String q3a="CREATE TABLE olympicpartnew(Athelete_Name string, age int,country string, closing_date string, sport string, gold_medal int, " + "silver_medal int, bronze_medal int, total_medal int)partitioned by(year int) row format delimited fields terminated by ',' ";
            st.execute(q3a);
            st.execute("set hive.exec.dynamic.partition.mode=nonstrict");
            String q3b="insert overwrite table olympicpartnew partition(year) select Athelete_Name, age, country,year, closing_date, sport, gold_medal, silver_medal, bronze_medal, total_medal from olympic ";
            st.execute(q3b);

            System.out.println("Partition created and data loaded");
            con.close();
    }
    }


