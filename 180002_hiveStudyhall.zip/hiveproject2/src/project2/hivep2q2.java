package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class hivep2q2 {
	private static String driver="org.apache.hive.jdbc.HiveDriver";
    private static Connection con=null;
    private static Statement st=null;

    public static void main(String[]args)throws SQLException,
ClassNotFoundException{

            Class.forName(driver);
            con=DriverManager.getConnection("jdbc:hive2://localhost:10000/default","","");
            st=con.createStatement();

            //loading data
            String q2="load data local inpath'/home/cloudera/Downloads/olympic_dataset.csv' overwrite into table olympic";
            st.execute(q2);
            System.out.println("data loaded");

            con.close();
    }

}
